package BaseClass;

import org.testng.annotations.Test;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

import org.testng.annotations.BeforeClass;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterClass;

public class samplebaseclass {
	
	static AppiumDriver<MobileElement> driver;
  @Test
  public void f() {
  }
  @BeforeClass
  public void beforeClass() throws Exception {
	  DesiredCapabilities caps = new DesiredCapabilities();
	  caps.setCapability("deviceName", "emulator-5554");
	  caps.setCapability("platformName", "android");
	  caps.setCapability("appPackage", "com.jayway.contacts");
	  caps.setCapability("appActivity", "com.jayway.contacts.MainActivity");
	  caps.setCapability("app", "/Applications/Contacts.apk");
	  
	  URL url = new URL("http://127.0.0.1:4723/wd/hub");
	  driver = new AppiumDriver<MobileElement>(url, caps);
	  
  }

//  @AfterClass
//  public void afterClass() {
//  }

}
