package pages;

import java.time.Duration;

import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

public class searchobject {

	public searchobject(AppiumDriver<MobileElement>driver) {

		PageFactory.initElements(new AppiumFieldDecorator(driver, Duration.ofSeconds(10)), this);
//		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
		

	}

	@AndroidFindBy (id = "com.jayway.contacts:id/main_search")
	@iOSXCUITFindBy (xpath = "//XCUIElementTypeSearchField[@name=\'Search for contact\']")
	MobileElement searchField;

	@AndroidFindBy (id = "com.jayway.contacts:id/name")
	@iOSXCUITFindBy (xpath = "//XCUIElementTypeStaticText[@name='Sara Alston']")
	MobileElement validsearchresult;

	@AndroidFindBy (id = "com.jayway.contacts:id/main_text")
	@iOSXCUITFindBy (xpath = "//XCUIElementTypeStaticText[@name=\'No Results\']")
	MobileElement invalidseachresult;

	public void search(String name) {
		searchField.clear();
		searchField.sendKeys(name);
	}

	public String validsearchresult() {
		String name = validsearchresult.getText();
		return name;
	}

	public String invalidseachresult() {
		String name = invalidseachresult.getText();
		return name;
	}

}
