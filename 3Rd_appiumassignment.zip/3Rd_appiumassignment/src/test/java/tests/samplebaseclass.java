package tests;

import java.net.URL;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class samplebaseclass {

	public AppiumDriver<MobileElement> driver;
	String platform;

  @BeforeClass
  public void beforeClass() throws Exception {

	try {
		DesiredCapabilities caps = new DesiredCapabilities();

		this.platform = "iOS";

		if(platform.equalsIgnoreCase("Android")) {

		  caps.setCapability("deviceName", "emulator-5554");
		  caps.setCapability("platformName", "android");
		  caps.setCapability("appPackage", "com.jayway.contacts");
		  caps.setCapability("appActivity", "com.jayway.contacts.MainActivity");
		  caps.setCapability("app", "/Applications/Contacts.apk");

		}
		else if (platform.equalsIgnoreCase("ios")) {
			caps.setCapability("deviceName", "iPhone 8 Plus");
			caps.setCapability("platformVersion", "13.4");
			caps.setCapability("platformName", "iOS");
			caps.setCapability("automationName", "XCUITest");
			caps.setCapability("udid", "73DF6523-3E52-4E3B-94BF-33F38B8ACAE9");
			caps.setCapability("app", "/Applications/ContactsSimulator.app");

		}
		
		URL url = new URL("http://127.0.0.1:4723/wd/hub");
		driver = new AppiumDriver<MobileElement>(url, caps);
		}

	catch (Exception exp)
		{
		System.out.println("Cause is :" +exp.getCause());
		System.out.println("Message is :" +exp.getMessage());
		exp.printStackTrace();
		}
	}



//  @AfterClass
//  public void afterClass() {
//	  driver.quit();
//  }

}
