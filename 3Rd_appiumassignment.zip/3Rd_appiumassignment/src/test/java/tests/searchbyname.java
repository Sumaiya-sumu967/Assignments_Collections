package tests;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.testng.Assert;
import org.testng.annotations.Test;

import pages.searchobject;

public class searchbyname extends samplebaseclass{
searchobject contactpage;

	@Test (priority = 2, enabled=true)
	public void searchSara() throws InterruptedException {
		Thread.sleep(2000);

		try {
		contactpage = new searchobject(driver);
		contactpage.search("Sara");
		String name = contactpage.validsearchresult();
		AssertJUnit.assertEquals(name, "Sara Alston");
		}catch (Exception e){
			System.out.println("Error message of searchname class"+e);
		}


	}


	@Test (priority = 1, enabled = true, dependsOnMethods= {"searchSara"})
	public void SearchTamim() {
		contactpage = new searchobject(driver);
		contactpage.search("Tamim");
		String expected_text;

		if (super.platform == "ios")
			expected_text = "No Results";
		else
			expected_text = "No contacts found with \"Tamim\" in the name";

		String actual_text = contactpage.invalidseachresult();
		AssertJUnit.assertEquals(actual_text, expected_text);

		}

	}

